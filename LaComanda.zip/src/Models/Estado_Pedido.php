<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Estado_Pedido extends Model
{
     public $timestamps = false;
     protected $table = 'estados_pedidos'; 

}