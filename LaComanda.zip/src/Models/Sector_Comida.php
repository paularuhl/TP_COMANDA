<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sector_Comida extends Model
{
    public $timestamps = false;
    protected $table = 'sectores_comidas'; 
}