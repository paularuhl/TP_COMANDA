<?php

namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Mesa;
use App\Models\Estado_Mesa;

use App\Models\Usuario;

use App\Models\Alumno_Materia;
use App\Models\Profesor_Materia;

use \Firebase\JWT\JWT;

class EncuestaController
{


}
