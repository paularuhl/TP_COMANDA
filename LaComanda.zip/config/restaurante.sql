-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-12-2020 a las 18:50:12
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `restaurante`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comidas`
--

CREATE TABLE `comidas` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `tipo` int(1) NOT NULL,
  `precio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `comidas`
--

INSERT INTO `comidas` (`id`, `nombre`, `tipo`, `precio`) VALUES
(1, 'Martini', 1, 10),
(2, 'IPA', 2, 7),
(3, 'Milanesa con Papas', 3, 25),
(4, 'Flan', 4, 15),
(5, 'HONEY', 2, 10),
(6, 'Pollo Al Champignon', 3, 20),
(7, 'Gelatina', 4, 5),
(8, 'Caipirinha', 1, 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuestas`
--

CREATE TABLE `encuestas` (
  `id` int(11) NOT NULL,
  `idMozo` int(11) DEFAULT NULL,
  `idCocinero` int(11) DEFAULT NULL,
  `idMesa` int(11) NOT NULL,
  `descripcion` varchar(66) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_mesas`
--

CREATE TABLE `estados_mesas` (
  `id` int(11) NOT NULL,
  `estadoMesa` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estados_mesas`
--

INSERT INTO `estados_mesas` (`id`, `estadoMesa`) VALUES
(1, 'Con cliente esperando pedido'),
(2, 'Con clientes comiendo'),
(3, 'Con clientes pagando'),
(4, 'Cerrada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_pedidos`
--

CREATE TABLE `estados_pedidos` (
  `id` int(11) NOT NULL,
  `estadoPedido` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estados_pedidos`
--

INSERT INTO `estados_pedidos` (`id`, `estadoPedido`) VALUES
(1, 'Pendiente'),
(2, 'En preparación'),
(3, 'Listo para servir');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mesas`
--

CREATE TABLE `mesas` (
  `id` int(5) NOT NULL,
  `idEstado` int(11) DEFAULT 4,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `mesas`
--

INSERT INTO `mesas` (`id`, `idEstado`, `created_at`, `updated_at`) VALUES
(11111, 1, '2020-11-29 21:18:01', '2020-12-01 07:55:37'),
(11112, 4, '2020-11-29 21:18:01', '2020-11-29 21:18:01'),
(11113, 4, '2020-11-29 21:18:01', '2020-11-29 21:18:01'),
(11114, 4, '2020-11-29 21:18:02', '2020-11-29 21:18:02'),
(11115, 4, '2020-11-29 21:18:02', '2020-11-29 21:18:02'),
(11116, 4, '2020-11-29 21:18:02', '2020-11-29 21:18:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mesas_pedidos`
--

CREATE TABLE `mesas_pedidos` (
  `idMesa` int(5) NOT NULL,
  `idPedido` varchar(5) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `mesas_pedidos`
--

INSERT INTO `mesas_pedidos` (`idMesa`, `idPedido`, `created_at`, `updated_at`, `id`) VALUES
(11111, 'A1000', '2020-12-01 07:55:38', '2020-12-01 07:55:38', 13);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `idPedido` varchar(5) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `idEstado` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `nombre_cliente` varchar(50) NOT NULL,
  `idMesa` int(3) NOT NULL,
  `costoTotal` int(11) NOT NULL,
  `tiempoEstimadoPreparacion` int(11) DEFAULT 0,
  `tiempoRestantePedido` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`idPedido`, `idEstado`, `nombre_cliente`, `idMesa`, `costoTotal`, `tiempoEstimadoPreparacion`, `tiempoRestantePedido`, `created_at`, `updated_at`) VALUES
('A1000', '2', 'Paula', 11111, 32, 43, 9, '2020-12-01 07:55:37', '2020-12-01 09:35:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos_comidas`
--

CREATE TABLE `pedidos_comidas` (
  `idPedido` varchar(11) NOT NULL,
  `idComida` int(11) NOT NULL,
  `idEstado` int(11) NOT NULL,
  `idEmpleado` int(11) DEFAULT NULL,
  `idMozo` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pedidos_comidas`
--

INSERT INTO `pedidos_comidas` (`idPedido`, `idComida`, `idEstado`, `idEmpleado`, `idMozo`, `id`) VALUES
('A1000', 2, 2, NULL, 10, 29),
('A1000', 3, 2, NULL, 10, 30);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idUsuario` int(11) NOT NULL,
  `tipo` varchar(15) NOT NULL,
  `estado` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(8) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `cantidadOperaciones` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idUsuario`, `tipo`, `estado`, `email`, `password`, `created_at`, `updated_at`, `cantidadOperaciones`) VALUES
(2, 'admin', 'activo', 'admin@mail.com', '12345678', '2020-11-30 01:11:46', '2020-11-30 01:11:46', 0),
(3, 'socio', 'activo', 'socio1@mail.com', '12345678', '2020-11-30 01:12:13', '2020-11-30 01:12:13', 0),
(4, 'socio', 'activo', 'socio2@mail.com', '12345678', '2020-11-30 01:12:16', '2020-11-30 01:12:16', 0),
(5, 'socio', 'activo', 'socio3@mail.com', '12345678', '2020-11-30 01:12:20', '2020-11-30 01:12:20', 0),
(6, 'cervecero', 'activo', 'empleado1@mail.com', '12345678', '2020-11-30 03:37:51', '2020-11-30 03:37:51', 0),
(7, 'bartender', 'activo', 'empleado2@mail.com', '12345678', '2020-11-30 03:37:59', '2020-11-30 03:37:59', 0),
(8, 'cocinero', 'activo', 'empleado3@mail.com', '12345678', '2020-11-30 03:38:11', '2020-11-30 03:38:11', 0),
(9, 'cocinero', 'activo', 'empleado4@mail.com', '12345678', '2020-11-30 03:38:14', '2020-11-30 03:38:14', 0),
(10, 'mozo', 'activo', 'empleado5@mail.com', '12345678', '2020-11-30 03:41:53', '2020-11-30 03:41:53', 0),
(11, 'mozo', 'suspendido', 'empleado6@mail.com', '12345678', '2020-11-30 03:45:55', '2020-11-30 03:45:55', 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `comidas`
--
ALTER TABLE `comidas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `encuestas`
--
ALTER TABLE `encuestas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estados_pedidos`
--
ALTER TABLE `estados_pedidos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mesas`
--
ALTER TABLE `mesas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mesas_pedidos`
--
ALTER TABLE `mesas_pedidos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`idPedido`);

--
-- Indices de la tabla `pedidos_comidas`
--
ALTER TABLE `pedidos_comidas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idUsuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `comidas`
--
ALTER TABLE `comidas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `encuestas`
--
ALTER TABLE `encuestas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `mesas`
--
ALTER TABLE `mesas`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11117;

--
-- AUTO_INCREMENT de la tabla `mesas_pedidos`
--
ALTER TABLE `mesas_pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `pedidos_comidas`
--
ALTER TABLE `pedidos_comidas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
